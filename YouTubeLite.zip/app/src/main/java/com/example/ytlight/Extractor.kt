@file:OptIn(androidx.media3.common.util.UnstableApi::class)

/*
 استخراج روابط الفيديو على الجهاز نفسه (بنفس طريقة تطبيق NewPipe).

 لماذا؟ خوادم Piped العامة تعمل من عناوين IP لمراكز بيانات، ويوتيوب يحجبها، فتنجح قوائم
 الفيديوهات لكن طلب روابط التشغيل (/streams) يفشل بـ HTTP 403. أما الاستخراج من هاتفك فيمرّ
 كأنه تطبيق عادي.

 المكتبة المستخدمة: NewPipeExtractor (GPL-3.0-or-later) — لذلك يخضع هذا التطبيق لرخصة GPL-3.0.
*/

package com.example.ytlight

import android.content.Context
import android.net.Uri
import androidx.core.text.HtmlCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.dash.DashMediaSource
import androidx.media3.exoplayer.dash.DefaultDashChunkSource
import androidx.media3.exoplayer.dash.manifest.DashManifestParser
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.RequestBody.Companion.toRequestBody
import org.schabi.newpipe.extractor.Image
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.services.youtube.dashmanifestcreators.YoutubeOtfDashManifestCreator
import org.schabi.newpipe.extractor.services.youtube.dashmanifestcreators.YoutubeProgressiveDashManifestCreator
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.AudioTrackType
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.Description
import org.schabi.newpipe.extractor.stream.Stream
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import org.schabi.newpipe.extractor.stream.StreamType
import org.schabi.newpipe.extractor.stream.VideoStream
import java.io.ByteArrayInputStream
import java.util.concurrent.TimeUnit

/** عميل HTTP الذي تستخدمه المكتبة لطلب صفحات يوتيوب (مأخوذ من DownloaderImpl في NewPipe). */
object YtDownloader : Downloader() {
    const val UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0"

    private val client = okhttp3.OkHttpClient.Builder()
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    override fun execute(request: Request): Response {
        val body = request.dataToSend()?.toRequestBody()
        val rb = okhttp3.Request.Builder()
            .method(request.httpMethod(), body)
            .url(request.url())
            .addHeader("User-Agent", UA)
        for ((name, values) in request.headers()) {
            rb.removeHeader(name)
            for (v in values) rb.addHeader(name, v)
        }
        return client.newCall(rb.build()).execute().use { r ->
            if (r.code == 429) throw ReCaptchaException("reCaptcha Challenge requested", request.url())
            val text = r.body?.string() ?: ""
            Response(r.code, r.message, r.headers.toMultimap(), text, r.request.url.toString())
        }
    }
}

object YtExtractor {
    @Volatile private var ready = false

    private fun ensureInit(region: String) {
        val country = ContentCountry(region.ifBlank { "US" }.uppercase())
        synchronized(this) {
            if (!ready) {
                NewPipe.init(YtDownloader, Localization("en", "US"), country)
                ready = true
            } else {
                NewPipe.setPreferredContentCountry(country)
            }
        }
    }

    private fun bestThumb(imgs: List<Image>?, id: String): String =
        imgs?.maxByOrNull { it.height }?.url ?: "https://i.ytimg.com/vi/$id/hqdefault.jpg"

    suspend fun details(id: String, region: String): Details = withContext(Dispatchers.IO) {
        ensureInit(region)
        val info = StreamInfo.getInfo(ServiceList.YouTube, "https://www.youtube.com/watch?v=$id")

        val video = (info.videoStreams.orEmpty() + info.videoOnlyStreams.orEmpty())
            .filter { !it.content.isNullOrBlank() }
            .map { VStream(it.content, it.height, it.isVideoOnly, it.format?.mimeType ?: "", it.bitrate, it) }

        val allAudio = info.audioStreams.orEmpty().filter { !it.content.isNullOrBlank() }
        val audio = allAudio
            .filter { it.audioTrackType == null || it.audioTrackType == AudioTrackType.ORIGINAL }
            .ifEmpty { allAudio }
            .map { AStream(it.content, it.format?.mimeType ?: "", it.averageBitrate, it) }

        val dsc = info.description
        val dscText = dsc?.content.orEmpty()
        val description = (if (dsc?.type == Description.HTML)
            HtmlCompat.fromHtml(dscText, HtmlCompat.FROM_HTML_MODE_COMPACT).toString() else dscText).trim()

        val related = info.relatedItems.orEmpty().mapNotNull { it as? StreamInfoItem }.mapNotNull { s ->
            val vid = s.url.orEmpty().substringAfter("v=", "").substringBefore("&")
            if (vid.length != 11) null else VideoItem(
                id = vid, title = s.name.orEmpty(), channel = s.uploaderName.orEmpty(),
                thumb = bestThumb(s.thumbnails, vid), duration = s.duration.coerceAtLeast(0),
                views = s.viewCount.coerceAtLeast(0), whenText = s.textualUploadDate.orEmpty(),
                avatar = s.uploaderAvatars?.firstOrNull()?.url.orEmpty(), verified = s.isUploaderVerified
            )
        }

        Details(
            id = id, title = info.name.orEmpty(), channel = info.uploaderName.orEmpty(),
            description = description, thumb = bestThumb(info.thumbnails, id),
            duration = info.duration, views = info.viewCount, likes = info.likeCount,
            live = info.streamType == StreamType.LIVE_STREAM || info.streamType == StreamType.AUDIO_LIVE_STREAM,
            hls = info.hlsUrl?.takeIf { it.isNotBlank() },
            video = video, audio = audio, subs = emptyList(), related = related, info = info
        )
    }
}

/** بناء مصادر التشغيل لروابط يوتيوب — منقول من PlaybackResolver / PlayerDataSource في NewPipe. */
object YtPlayback {
    // range=false: تُستخدم ترويسة Range العادية مع ProgressiveMediaSource (وإلا يتعطّل التشغيل)
    // range=true : مع مانيفست DASH، ويُرسل المدى كوسيط في الرابط (&range=)
    private fun ytFactory(range: Boolean, rn: Boolean) =
        YoutubeHttpDataSource.Factory().setRangeParameterEnabled(range).setRnParameterEnabled(rn)

    private fun dash(xml: String, s: Stream, item: MediaItem): MediaSource {
        val manifest = DashManifestParser().parse(
            Uri.parse(s.manifestUrl ?: ""), ByteArrayInputStream(xml.toByteArray(Charsets.UTF_8))
        )
        val f = ytFactory(true, true)
        return DashMediaSource.Factory(DefaultDashChunkSource.Factory(f), f).createMediaSource(manifest, item)
    }

    private fun streamSource(s: Stream, durationSec: Long, meta: MediaMetadata): MediaSource {
        val item = MediaItem.Builder().setUri(Uri.parse(s.content)).setMediaMetadata(meta).build()
        val videoOnlyOrAudio = s is AudioStream || (s is VideoStream && s.isVideoOnly)
        return when (s.deliveryMethod) {
            DeliveryMethod.PROGRESSIVE_HTTP -> {
                var src: MediaSource? = null
                if (videoOnlyOrAudio) {
                    try {
                        val xml = YoutubeProgressiveDashManifestCreator
                            .fromProgressiveStreamingUrl(s.content, s.itagItem!!, durationSec)
                        src = dash(xml, s, item)
                    } catch (e: Exception) {
                        // نرجع إلى التشغيل التدريجي العادي
                    }
                }
                src ?: ProgressiveMediaSource.Factory(ytFactory(false, true)).createMediaSource(item)
            }
            DeliveryMethod.DASH -> {
                val xml = YoutubeOtfDashManifestCreator.fromOtfStreamingUrl(s.content, s.itagItem!!, durationSec)
                dash(xml, s, item)
            }
            DeliveryMethod.HLS -> HlsMediaSource.Factory(ytFactory(false, false)).createMediaSource(item)
            else -> error("طريقة بث غير مدعومة: ${s.deliveryMethod}")
        }
    }

    private fun pickAudio(d: Details): AStream? {
        val l = d.audio.filter { it.src != null }
        return l.filter { it.mime.contains("mp4") }.ifEmpty { l }.maxByOrNull { it.bitrate }
    }

    fun build(ctx: Context, d: Details, info: StreamInfo, video: VStream?, audioOnly: Boolean): MediaSource {
        val meta = MediaMetadata.Builder().setTitle(d.title).setArtist(d.channel)
            .setArtworkUri(Uri.parse(d.thumb)).build()

        // البث المباشر: HLS
        if (d.live && d.hls != null) {
            val http = DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true).setUserAgent(YtDownloader.UA)
            return HlsMediaSource.Factory(DefaultDataSource.Factory(ctx, http))
                .createMediaSource(MediaItem.Builder().setUri(d.hls).setMediaMetadata(meta).build())
        }

        val a = pickAudio(d)
        if (a != null && (audioOnly || video == null)) return streamSource(a.src!!, info.duration, meta)
        if (video == null) error("لا توجد مصادر تشغيل لهذا الفيديو")

        val vSrc = streamSource(video.src!!, info.duration, meta)
        return if (video.videoOnly && a != null) MergingMediaSource(vSrc, streamSource(a.src!!, info.duration, meta))
        else vSrc
    }
}
