@file:OptIn(androidx.media3.common.util.UnstableApi::class)

/*
 ╔══════════════════════════════════════════════════════════════════╗
 ║  YouTube Light — تطبيق كامل في ملف واحد                           ║
 ╚══════════════════════════════════════════════════════════════════╝

 التشغيل:
 1) Android Studio ← New Project ← Empty Activity (Compose)، وليكن الـ package: com.example.ytlight
 2) استبدل MainActivity.kt بهذا الملف (غيّر سطر package إذا اخترت اسماً آخر)
 3) أضف هذه الاعتماديات في app/build.gradle.kts:

    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")
    implementation("androidx.media3:media3-session:1.4.1")
    implementation("io.coil-kt:coil-compose:2.7.0")

    // للإصدار النهائي (لتصغير الحجم):
    buildTypes { release { isMinifyEnabled = true; isShrinkResources = true } }

 4) AndroidManifest.xml (ضع الصلاحيات خارج <application> والباقي داخلها):

    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.WAKE_LOCK"/>

    <application android:supportsRtl="true" ... >
      <activity android:name=".MainActivity" android:exported="true"
          android:launchMode="singleTask" android:supportsPictureInPicture="true"
          android:configChanges="orientation|screenSize|smallestScreenSize|screenLayout|keyboardHidden">
        <intent-filter>
          <action android:name="android.intent.action.MAIN"/>
          <category android:name="android.intent.category.LAUNCHER"/>
        </intent-filter>
        <intent-filter>   <!-- فتح روابط يوتيوب داخل التطبيق -->
          <action android:name="android.intent.action.VIEW"/>
          <category android:name="android.intent.category.DEFAULT"/>
          <category android:name="android.intent.category.BROWSABLE"/>
          <data android:scheme="https" android:host="youtu.be"/>
          <data android:scheme="https" android:host="www.youtube.com" android:pathPrefix="/watch"/>
          <data android:scheme="https" android:host="m.youtube.com" android:pathPrefix="/watch"/>
        </intent-filter>
      </activity>
      <service android:name=".PlaybackService" android:exported="true"
          android:foregroundServiceType="mediaPlayback">
        <intent-filter>
          <action android:name="androidx.media3.session.MediaSessionService"/>
        </intent-filter>
      </service>
    </application>

 5) الخط (اختياري، موصى به): حمّل Tajawal (أو Cairo) من Google Fonts وضع هذه الملفات في
    app/src/main/assets/fonts/ :
        Tajawal-Regular.ttf  Tajawal-Medium.ttf  Tajawal-Bold.ttf
    (أو Cairo-Regular / Cairo-Medium / Cairo-Bold — موجودة في مجلد static داخل ملف التحميل).
    إن لم توجد الملفات يستخدم التطبيق خط النظام تلقائياً دون أي خطأ.

 ملاحظة: خوادم Piped تتغير وتتعطل أحياناً — غيّر الخادم من الإعدادات إذا فشل التحميل.
*/

package com.example.ytlight

import android.Manifest
import android.app.Application
import android.app.PictureInPictureParams
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.activity.SystemBarStyle
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.outlined.Home as HomeOutlined
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.addPathNodes
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.text.HtmlCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

// ════════════════════════════ 1) النماذج ════════════════════════════

val DEFAULT_INSTANCES = listOf(
    "https://pipedapi.kavin.rocks",
    "https://api.piped.private.coffee",
    "https://pipedapi.adminforge.de"
)

sealed interface Load<out T> {
    object Busy : Load<Nothing>
    data class Ok<out T>(val v: T) : Load<T>
    data class Err(val msg: String) : Load<Nothing>
}

data class VideoItem(
    val id: String, val title: String, val channel: String, val thumb: String,
    val duration: Long = 0, val views: Long = 0, val uploaded: Long = 0, val whenText: String = "",
    val avatar: String = "", val verified: Boolean = false
)

// src = الكائن الأصلي من NewPipeExtractor (يلزم لبناء مصدر التشغيل)؛ يكون null إن جاءت الروابط من Piped
data class VStream(
    val url: String, val height: Int, val videoOnly: Boolean, val mime: String, val bitrate: Int,
    val src: org.schabi.newpipe.extractor.stream.VideoStream? = null
)
data class AStream(
    val url: String, val mime: String, val bitrate: Int,
    val src: org.schabi.newpipe.extractor.stream.AudioStream? = null
)
data class Sub(val url: String, val mime: String, val code: String)

data class Details(
    val id: String, val title: String, val channel: String, val description: String, val thumb: String,
    val duration: Long, val views: Long, val likes: Long, val live: Boolean, val hls: String?,
    val video: List<VStream>, val audio: List<AStream>, val subs: List<Sub>, val related: List<VideoItem>,
    val info: org.schabi.newpipe.extractor.stream.StreamInfo? = null
)

// ════════════════════════════ 2) الشبكة (Piped API) ════════════════════════════

fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
fun JSONObject.str(k: String): String? = if (isNull(k)) null else optString(k).takeIf { it.isNotBlank() }

/** روابط الصور من Piped تمرّ عبر بروكسي (?host=…) كثيراً ما يُحجب؛ نعيدها إلى الرابط المباشر (i.ytimg.com …). */
fun directImg(u: String): String {
    val host = Regex("[?&]host=([^&]+)").find(u)?.groupValues?.get(1) ?: return u
    val path = u.substringAfter("://").substringAfter("/", "").substringBefore("?")
    return if (path.isBlank()) u else "https://$host/$path"
}

fun JSONObject.toVideo(): VideoItem? {
    val url = optString("url")
    if (!url.startsWith("/watch")) return null
    // str() بدل optString: الأخيرة تُرجع النص "null" عندما تكون القيمة null (كانت تظهر "null" في القوائم)
    return VideoItem(
        id = url.substringAfter("v=").substringBefore("&"),
        title = str("title") ?: "", channel = str("uploaderName") ?: "", thumb = directImg(str("thumbnail") ?: ""),
        duration = optLong("duration"), views = optLong("views"), uploaded = optLong("uploaded"),
        whenText = str("uploadedDate") ?: "", avatar = directImg(str("uploaderAvatar") ?: ""),
        verified = optBoolean("uploaderVerified")
    )
}

fun JSONArray.videos(): List<VideoItem> =
    (0 until length()).mapNotNull { optJSONObject(it)?.toVideo() }.distinctBy { it.id }

object Api {
    @Volatile var instance = DEFAULT_INSTANCES[0]
    @Volatile var region = "US"
    private val cache = LinkedHashMap<String, Pair<Long, String>>()

    fun clear() = synchronized(cache) { cache.clear() }

    /** يجرّب الخادم المختار ثم الاحتياطيين، مع كاش بسيط في الذاكرة. */
    suspend fun get(path: String, ttl: Long = 5 * 60_000): String = withContext(Dispatchers.IO) {
        val hit = synchronized(cache) {
            cache[path]?.takeIf { System.currentTimeMillis() - it.first < ttl }?.second
        }
        if (hit != null) return@withContext hit
        var last: Exception? = null
        for (base in listOf(instance) + DEFAULT_INSTANCES.filter { it != instance }) {
            try {
                val c = URL(base.trimEnd('/') + path).openConnection() as HttpURLConnection
                c.connectTimeout = 8_000
                c.readTimeout = 15_000
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) YouTubeLight/1.0")
                if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
                val body = c.inputStream.bufferedReader().use { it.readText() }
                synchronized(cache) {
                    cache[path] = System.currentTimeMillis() to body
                    if (cache.size > 40) cache.remove(cache.keys.first())
                }
                return@withContext body
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: IOException("لا يوجد خادم متاح")
    }

    /**
     * الأساس: استخراج الروابط على الجهاز (NewPipeExtractor). إن فشل نجرّب خوادم Piped كاحتياط.
     * خوادم Piped العامة محجوبة غالباً من يوتيوب فتُرجع HTTP 403 عند طلب /streams.
     */
    suspend fun details(id: String, fresh: Boolean = false): Details {
        var extractorError: Throwable? = null
        try {
            return YtExtractor.details(id, region)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            extractorError = e
        }
        try {
            return pipedDetails(id, fresh)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val x = extractorError
            val first = x?.message?.lineSequence()?.firstOrNull()?.take(160) ?: x?.javaClass?.simpleName ?: "?"
            throw IOException("المستخرج: $first\nPiped: ${e.message}")
        }
    }

    private suspend fun pipedDetails(id: String, fresh: Boolean): Details {
        val j = JSONObject(get("/streams/$id", if (fresh) 0 else 120_000))
        fun arr(k: String) = j.optJSONArray(k) ?: JSONArray()
        fun objs(k: String) = arr(k).let { a -> (0 until a.length()).mapNotNull { a.optJSONObject(it) } }
        return Details(
            id = id, title = j.optString("title"), channel = j.optString("uploader"),
            description = HtmlCompat.fromHtml(j.optString("description"), HtmlCompat.FROM_HTML_MODE_COMPACT).toString().trim(),
            thumb = directImg(j.optString("thumbnailUrl")), duration = j.optLong("duration"),
            views = j.optLong("views"), likes = j.optLong("likes", -1),
            live = j.optBoolean("livestream"), hls = j.str("hls"),
            video = objs("videoStreams").filter { it.str("url") != null }.map {
                VStream(it.getString("url"), it.optInt("height"), it.optBoolean("videoOnly"), it.optString("mimeType"), it.optInt("bitrate"))
            },
            audio = objs("audioStreams").filter { it.str("url") != null }.map {
                AStream(it.getString("url"), it.optString("mimeType"), it.optInt("bitrate"))
            },
            subs = objs("subtitles").filter { it.str("url") != null }.map {
                Sub(it.getString("url"), it.optString("mimeType"), it.optString("code"))
            },
            related = arr("relatedStreams").videos()
        )
    }
}

// ════════════════════════════ 3) المشغّل والخدمة الخلفية ════════════════════════════

/** مشغّل واحد مشترك بين الواجهة والخدمة ← التشغيل يستمر عند إغلاق الشاشة. */
object PlayerHolder {
    @Volatile private var p: ExoPlayer? = null
    fun get(ctx: Context): ExoPlayer = p ?: synchronized(this) {
        p ?: ExoPlayer.Builder(ctx.applicationContext)
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build().also { p = it }
    }
}

class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        session = MediaSession.Builder(this, PlayerHolder.get(this)).build().also { addSession(it) }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        session?.release()
        session = null
        super.onDestroy()
    }
}

fun qualityOptions(d: Details): List<VStream> {
    val mp4 = d.video.filter { it.mime.contains("mp4") }.ifEmpty { d.video }
    return mp4.groupBy { it.height }
        .map { (_, l) -> l.sortedWith(compareBy<VStream>({ it.videoOnly }, { -it.bitrate })).first() }
        .sortedByDescending { it.height }
}

fun pickDefault(opts: List<VStream>, saver: Boolean): VStream? {
    val target = if (saver) 360 else 720
    return opts.firstOrNull { it.height <= target } ?: opts.lastOrNull()
}

fun buildSource(ctx: Context, d: Details, video: VStream?, audioOnly: Boolean): MediaSource {
    // الروابط المستخرجة على الجهاز تحتاج مصدر بيانات خاصاً بيوتيوب (انظر Extractor.kt)
    d.info?.let { return YtPlayback.build(ctx, d, it, video, audioOnly) }

    // احتياطي: روابط قادمة من Piped
    val http = DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true).setUserAgent("Mozilla/5.0 (Android)")
    val factory = DefaultMediaSourceFactory(DefaultDataSource.Factory(ctx, http))
    val meta = MediaMetadata.Builder().setTitle(d.title).setArtist(d.channel).setArtworkUri(Uri.parse(d.thumb)).build()
    val audio = d.audio.filter { it.mime.contains("mp4") }.ifEmpty { d.audio }.maxByOrNull { it.bitrate }

    if (d.hls != null && (d.live || d.video.isEmpty())) {
        return factory.createMediaSource(
            MediaItem.Builder().setUri(d.hls).setMimeType(MimeTypes.APPLICATION_M3U8).setMediaMetadata(meta).build()
        )
    }
    if (audio != null && (audioOnly || video == null)) {
        return factory.createMediaSource(MediaItem.Builder().setUri(audio.url).setMediaMetadata(meta).build())
    }
    if (video == null) error("لا توجد مصادر تشغيل لهذا الفيديو")

    // الترجمة: العربية والإنجليزية فقط (تجنّب تحميل عشرات الملفات)
    val subs = d.subs.filter { it.code.startsWith("ar") || it.code.startsWith("en") }.take(4).map {
        MediaItem.SubtitleConfiguration.Builder(Uri.parse(it.url))
            .setMimeType(if (it.mime.contains("ttml")) MimeTypes.APPLICATION_TTML else MimeTypes.TEXT_VTT)
            .setLanguage(it.code).setLabel(it.code).build()
    }
    val vSrc = factory.createMediaSource(
        MediaItem.Builder().setUri(video.url).setMediaMetadata(meta).setSubtitleConfigurations(subs).build()
    )
    return if (video.videoOnly && audio != null)
        MergingMediaSource(vSrc, factory.createMediaSource(MediaItem.fromUri(audio.url)))
    else vSrc
}

// ════════════════════════════ 4) ViewModel ════════════════════════════

class AppVM(private val ctx: Application) : AndroidViewModel(ctx) {
    private val sp = ctx.getSharedPreferences("ytl", Context.MODE_PRIVATE)
    private fun put(f: SharedPreferences.Editor.() -> Unit) = sp.edit().apply(f).apply()

    // الإعدادات
    var instance by mutableStateOf(sp.getString("instance", DEFAULT_INSTANCES[0])!!)
    var region by mutableStateOf(sp.getString("region", "IQ")!!)
    var saver by mutableStateOf(sp.getBoolean("saver", false))
    var audioDefault by mutableStateOf(sp.getBoolean("audio", false))
    var theme by mutableIntStateOf(sp.getInt("theme", 2)) // 0 تلقائي، 1 فاتح، 2 داكن
    var dynamic by mutableStateOf(sp.getBoolean("dynamic", false))
    var dir by mutableIntStateOf(sp.getInt("dir", 0)) // 0 تلقائي، 1 LTR، 2 RTL

    // @JvmName يمنع تعارض الدالة مع setter الخاصية (Platform declaration clash)
    @JvmName("applySaver") fun setSaver(v: Boolean) { saver = v; put { putBoolean("saver", v) } }
    @JvmName("applyAudioDefault") fun setAudioDefault(v: Boolean) { audioDefault = v; put { putBoolean("audio", v) } }
    @JvmName("applyTheme") fun setTheme(v: Int) { theme = v; put { putInt("theme", v) } }
    @JvmName("applyDynamic") fun setDynamic(v: Boolean) { dynamic = v; put { putBoolean("dynamic", v) } }
    @JvmName("applyDir") fun setDir(v: Int) { dir = v; put { putInt("dir", v) } }
    fun saveServer(i: String, r: String) {
        val url = i.trim().trimEnd('/').ifBlank { DEFAULT_INSTANCES[0] }
        instance = if (url.startsWith("http")) url else "https://$url"
        region = r.ifBlank { "US" }
        Api.region = region
        Api.instance = instance
        put { putString("instance", instance); putString("region", region) }
        Api.clear(); loadHome()
    }

    /** صور مصغّرة بجودة منخفضة في وضع توفير البيانات */
    fun thumb(u: String): String {
        if (!saver) return u
        val m = Regex("^(.*/vi/[^/]+)/[^/?]+(\\?.*)?$").find(u) ?: return u
        val host = Regex("host=[^&]+").find(u)?.value
        return m.groupValues[1] + "/mqdefault.jpg" + (host?.let { "?$it" } ?: "")
    }

    // الرئيسية
    var home by mutableStateOf<Load<List<VideoItem>>>(Load.Busy)
    val cats = listOf(
        "الكل" to "", "موسيقى" to "موسيقى", "ألعاب" to "ألعاب",
        "برامج" to "برامج", "مباشر" to "بث مباشر", "أفلام" to "أفلام"
    )
    var cat by mutableIntStateOf(0)
    private var homeJob: Job? = null
    @JvmName("applyCat") fun setCat(i: Int) { cat = i; loadHome() }

    fun loadHome() {
        homeJob?.cancel()
        homeJob = viewModelScope.launch {
            home = Load.Busy
            home = try {
                val q = cats[cat].second
                val l = if (q.isEmpty()) {
                    var t = JSONArray(Api.get("/trending?region=$region")).videos()
                    if (t.isEmpty()) t = JSONArray(Api.get("/trending?region=US")).videos()
                    t
                } else JSONObject(Api.get("/search?q=${enc(q)}&filter=videos")).getJSONArray("items").videos()
                Load.Ok(l)
            } catch (e: CancellationException) { throw e } catch (e: Exception) { Load.Err(e.message ?: "خطأ في الاتصال") }
        }
    }

    // البحث
    var query by mutableStateOf("")
    var suggestions by mutableStateOf<List<String>>(emptyList())
    var filter by mutableStateOf("videos")
    var sort by mutableIntStateOf(0) // 0 الأكثر صلة، 1 الأحدث، 2 الأكثر مشاهدة
    var results by mutableStateOf<Load<List<VideoItem>>?>(null)
    var loadingMore by mutableStateOf(false)
    private var nextPage: String? = null
    private var lastQuery = ""
    private var sugJob: Job? = null
    private var searchJob: Job? = null

    fun onQuery(q: String) {
        query = q
        sugJob?.cancel()
        if (q.length < 2) { suggestions = emptyList(); return }
        sugJob = viewModelScope.launch {
            delay(250)
            suggestions = try {
                val a = JSONArray(Api.get("/suggestions?query=${enc(q)}", 60_000))
                (0 until a.length()).map { a.getString(it) }.take(6)
            } catch (e: CancellationException) { throw e } catch (e: Exception) { emptyList() }
        }
    }

    fun search(q: String = query) {
        if (q.isBlank()) return
        query = q; lastQuery = q; suggestions = emptyList(); nextPage = null
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            results = Load.Busy
            results = try {
                val j = JSONObject(Api.get("/search?q=${enc(q)}&filter=$filter"))
                nextPage = j.str("nextpage")
                Load.Ok(j.getJSONArray("items").videos())
            } catch (e: CancellationException) { throw e } catch (e: Exception) { Load.Err(e.message ?: "خطأ في البحث") }
        }
    }

    @JvmName("applyFilter") fun setFilter(f: String) { filter = f; if (lastQuery.isNotBlank()) search(lastQuery) }

    fun loadMore() {
        val np = nextPage ?: return
        val cur = (results as? Load.Ok)?.v ?: return
        if (loadingMore) return
        loadingMore = true
        viewModelScope.launch {
            try {
                val j = JSONObject(Api.get("/nextpage/search?nextpage=${enc(np)}&q=${enc(lastQuery)}&filter=$filter", 0))
                nextPage = j.str("nextpage")
                results = Load.Ok((cur + j.getJSONArray("items").videos()).distinctBy { it.id })
            } catch (e: CancellationException) { throw e } catch (e: Exception) { nextPage = null }
            loadingMore = false
        }
    }

    fun sorted(l: List<VideoItem>) = when (sort) {
        1 -> l.sortedByDescending { it.uploaded }
        2 -> l.sortedByDescending { it.views }
        else -> l
    }

    // المكتبة (محلية بالكامل — بدون حساب)
    var favs by mutableStateOf(loadList("fav"))
    var hist by mutableStateOf(loadList("hist"))

    private fun loadList(k: String): List<VideoItem> = try {
        val a = JSONArray(sp.getString(k, "[]"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            VideoItem(o.getString("id"), o.optString("t"), o.optString("c"), directImg(o.optString("th")), o.optLong("d"))
        }
    } catch (e: Exception) { emptyList() }

    private fun saveList(k: String, l: List<VideoItem>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("t", it.title).put("c", it.channel).put("th", it.thumb).put("d", it.duration)) }
        put { putString(k, a.toString()) }
    }

    fun isFav(id: String) = favs.any { it.id == id }
    fun toggleFav(v: VideoItem) {
        favs = if (isFav(v.id)) favs.filter { it.id != v.id } else listOf(v) + favs
        saveList("fav", favs)
    }
    private fun addHistory(v: VideoItem) {
        hist = (listOf(v) + hist.filter { it.id != v.id }).take(200)
        saveList("hist", hist)
    }
    fun clearHistory() { hist = emptyList(); saveList("hist", hist) }

    // المشغّل
    var playingId by mutableStateOf<String?>(null)
    var detail by mutableStateOf<Load<Details>>(Load.Busy)
    var quality by mutableStateOf<VStream?>(null)
    var audioOnly by mutableStateOf(false)
    var speed by mutableFloatStateOf(1f)
    var sleepMin by mutableIntStateOf(0)
    var playError by mutableStateOf<String?>(null)
    private var openJob: Job? = null
    private var sleepJob: Job? = null

    private val exo get() = PlayerHolder.get(ctx)

    fun open(id: String, fresh: Boolean = false) {
        openJob?.cancel()
        if (playingId == null) audioOnly = audioDefault
        playingId = id; playError = null; detail = Load.Busy
        openJob = viewModelScope.launch {
            val r = try { Load.Ok(Api.details(id, fresh)) } catch (e: CancellationException) { throw e } catch (e: Exception) {
                Load.Err(e.message ?: "تعذّر جلب الفيديو")
            }
            detail = r
            if (r is Load.Ok) {
                val d = r.v
                quality = pickDefault(qualityOptions(d), saver)
                addHistory(VideoItem(d.id, d.title, d.channel, d.thumb, d.duration))
                start(0)
            }
        }
    }

    private fun start(startMs: Long) {
        val d = (detail as? Load.Ok)?.v ?: return
        try {
            playError = null
            try { ctx.startService(Intent(ctx, PlaybackService::class.java)) } catch (e: Exception) {}
            val p = exo
            p.setMediaSource(buildSource(ctx, d, quality, audioOnly), startMs)
            p.setPlaybackSpeed(speed)
            p.prepare()
            p.play()
        } catch (e: Exception) { playError = e.message ?: "خطأ" }
    }

    @JvmName("applyQuality") fun setQuality(q: VStream) { val pos = exo.currentPosition; quality = q; audioOnly = false; start(pos) }
    fun toggleAudio() { val pos = exo.currentPosition; audioOnly = !audioOnly; start(pos) }
    @JvmName("applySpeed") fun setSpeed(s: Float) { speed = s; exo.setPlaybackSpeed(s) }

    fun sleep(min: Int) {
        sleepJob?.cancel(); sleepMin = min
        if (min > 0) sleepJob = viewModelScope.launch {
            delay(min * 60_000L)
            exo.pause(); sleepMin = 0
        }
    }

    fun close() {
        openJob?.cancel(); sleepJob?.cancel(); sleepMin = 0
        exo.stop(); exo.clearMediaItems()
        playingId = null; playError = null
    }

    init { Api.instance = instance; Api.region = region; loadHome() }
}

// ════════════════════════════ 5) النشاط الرئيسي ════════════════════════════

class MainActivity : ComponentActivity() {
    private val vm: AppVM by viewModels()
    private val pip = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) registerForActivityResult(ActivityResultContracts.RequestPermission()) {}.launch(Manifest.permission.POST_NOTIFICATIONS)
        handle(intent)
        setContent { AppTheme(vm) { Surface(color = MaterialTheme.colorScheme.background) { App(vm, pip.value) } } }
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handle(intent) }

    private fun handle(i: Intent?) {
        val u = i?.data ?: return
        val id = u.getQueryParameter("v") ?: if (u.host == "youtu.be") u.lastPathSegment else null
        if (id != null) vm.open(id)
    }

    override fun onUserLeaveHint() {
        if (Build.VERSION.SDK_INT >= 26 && vm.playingId != null && !vm.audioOnly && PlayerHolder.get(this).isPlaying) {
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        pip.value = isInPictureInPictureMode
    }
}

// ════════════════════════════ 6) الواجهة ════════════════════════════

// اسم العلامة (غيّره هنا فقط إن أردت اسماً آخر)
const val BRAND_A = "YouTube"
const val BRAND_B = "Lite"

private fun vec(d: String): ImageVector =
    ImageVector.Builder(defaultWidth = 24.dp, defaultHeight = 24.dp, viewportWidth = 24f, viewportHeight = 24f)
        .addPath(pathData = addPathNodes(d), pathFillType = PathFillType.EvenOdd, fill = SolidColor(Color.Black))
        .build()

private val ExploreIcon by lazy {
    vec("M12,10.9c-0.61,0 -1.1,0.49 -1.1,1.1s0.49,1.1 1.1,1.1c0.61,0 1.1,-0.49 1.1,-1.1s-0.49,-1.1 -1.1,-1.1zM12,2C6.48,2 2,6.48 2,12s4.48,10 10,10 10,-4.48 10,-10S17.52,2 12,2zM14.19,14.19L6,18l3.81,-8.19L18,6l-3.81,8.19z")
}
private val HistoryIcon by lazy {
    vec("M13,3c-4.97,0 -9,4.03 -9,9H1l3.89,3.89 0.07,0.14L9,12H6c0,-3.87 3.13,-7 7,-7s7,3.13 7,7 -3.13,7 -7,7c-1.93,0 -3.68,-0.79 -4.94,-2.06l-1.42,1.42C8.27,19.99 10.51,21 13,21c4.97,0 9,-4.03 9,-9s-4.03,-9 -9,-9zM12,8v5l4.28,2.54 0.72,-1.21 -3.5,-2.08V8H12z")
}

/** يبحث عن Tajawal ثم Cairo في assets/fonts؛ وإن لم يجد يستخدم خط النظام. */
@OptIn(ExperimentalTextApi::class)
@Composable
fun rememberAppFont(): FontFamily {
    val ctx = LocalContext.current
    return remember {
        val weights = listOf("Regular" to FontWeight.Normal, "Medium" to FontWeight.Medium, "Bold" to FontWeight.Bold)
        listOf("Tajawal", "Cairo").firstNotNullOfOrNull { n ->
            try {
                FontFamily(weights.map { (s, w) ->
                    val p = "fonts/$n-$s.ttf"
                    ctx.assets.open(p).close()
                    Font(assetManager = ctx.assets, path = p, weight = w)
                })
            } catch (e: Exception) { null }
        } ?: FontFamily.Default
    }
}

fun Typography.withFont(f: FontFamily) = copy(
    displayLarge = displayLarge.copy(fontFamily = f), displayMedium = displayMedium.copy(fontFamily = f),
    displaySmall = displaySmall.copy(fontFamily = f), headlineLarge = headlineLarge.copy(fontFamily = f),
    headlineMedium = headlineMedium.copy(fontFamily = f), headlineSmall = headlineSmall.copy(fontFamily = f),
    titleLarge = titleLarge.copy(fontFamily = f), titleMedium = titleMedium.copy(fontFamily = f),
    titleSmall = titleSmall.copy(fontFamily = f), bodyLarge = bodyLarge.copy(fontFamily = f),
    bodyMedium = bodyMedium.copy(fontFamily = f), bodySmall = bodySmall.copy(fontFamily = f),
    labelLarge = labelLarge.copy(fontFamily = f), labelMedium = labelMedium.copy(fontFamily = f),
    labelSmall = labelSmall.copy(fontFamily = f)
)

@Composable
fun AppTheme(vm: AppVM, content: @Composable () -> Unit) {
    val dark = when (vm.theme) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val ctx = LocalContext.current
    val font = rememberAppFont()

    // أيقونات شريط الحالة تتبع مظهر التطبيق (لا مظهر النظام)
    val act = ctx as? ComponentActivity
    SideEffect {
        val t = android.graphics.Color.TRANSPARENT
        val style = if (dark) SystemBarStyle.dark(t) else SystemBarStyle.light(t, t)
        act?.enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
    }

    val scheme = when {
        vm.dynamic && Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme(
            primary = Color(0xFFFF3B3B), onPrimary = Color.White,
            background = Color(0xFF0D0D11), onBackground = Color(0xFFF1F1F4),
            surface = Color(0xFF0D0D11), onSurface = Color(0xFFF1F1F4),
            surfaceVariant = Color(0xFF1F1F26), onSurfaceVariant = Color(0xFF8D97A8),
            surfaceContainer = Color(0xFF15151A), surfaceContainerHigh = Color(0xFF25252C),
            secondaryContainer = Color(0xFF3A1A1E), onSecondaryContainer = Color.White,
            outlineVariant = Color(0xFF2E2E36), error = Color(0xFFFF6B6B)
        )
        else -> lightColorScheme(
            primary = Color(0xFFE5121B), onPrimary = Color.White,
            background = Color.White, onBackground = Color(0xFF111114),
            surface = Color.White, onSurface = Color(0xFF111114),
            surfaceVariant = Color(0xFFF1F1F4), onSurfaceVariant = Color(0xFF5F6877),
            surfaceContainer = Color(0xFFF6F6F8), surfaceContainerHigh = Color(0xFFEDEDF1),
            secondaryContainer = Color(0xFFFFE0E0), onSecondaryContainer = Color.Black,
            outlineVariant = Color(0xFFDDDDE3)
        )
    }
    MaterialTheme(
        colorScheme = scheme,
        typography = Typography().withFont(font),
        shapes = Shapes(
            extraSmall = RoundedCornerShape(8.dp), small = RoundedCornerShape(12.dp),
            medium = RoundedCornerShape(16.dp), large = RoundedCornerShape(24.dp), extraLarge = RoundedCornerShape(32.dp)
        )
    ) {
        val dir = when (vm.dir) { 1 -> LayoutDirection.Ltr; 2 -> LayoutDirection.Rtl; else -> LocalLayoutDirection.current }
        CompositionLocalProvider(LocalLayoutDirection provides dir) { content() }
    }
}

fun fmt(s: Long): String {
    val h = s / 3600; val m = s % 3600 / 60; val x = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, x) else "%d:%02d".format(m, x)
}

fun compact(n: Long) = when {
    n >= 1_000_000 -> "%.1f مليون".format(n / 1e6)
    n >= 1_000 -> "%.0f ألف".format(n / 1e3)
    else -> "%d".format(n)
}

fun metaText(v: VideoItem, withChannel: Boolean) = listOf(
    if (withChannel) v.channel else "",
    if (v.views > 0) "${compact(v.views)} مشاهدة" else "",
    v.whenText
).filter { it.isNotBlank() }.joinToString(" • ")

fun share(ctx: Context, id: String) = ctx.startActivity(
    Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "https://youtu.be/$id")
    }, null)
)

fun extractId(s: String): String? {
    val x = s.trim()
    Regex("(?:v=|youtu\\.be/|/shorts/|/embed/|/live/)([A-Za-z0-9_-]{11})").find(x)?.let { return it.groupValues[1] }
    return x.takeIf { Regex("^[A-Za-z0-9_-]{11}$").matches(it) }
}

// ───────── مكوّنات عامة ─────────

@Composable
fun PillBox(selected: Boolean = false, onClick: () -> Unit, content: @Composable RowScope.() -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(
        onClick = onClick, shape = CircleShape,
        color = if (selected) cs.primary else cs.surfaceContainerHigh,
        contentColor = if (selected) cs.onPrimary else cs.onSurface
    ) {
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp), content = content
        )
    }
}

@Composable
fun Pill(label: String, selected: Boolean = false, onClick: () -> Unit) =
    PillBox(selected, onClick) { Text(label, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Medium) }

@Composable
fun <T> Picker(label: String, items: List<T>, name: (T) -> String, onPick: (T) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        Pill(label) { open = true }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            items.forEach { DropdownMenuItem(text = { Text(name(it)) }, onClick = { open = false; onPick(it) }) }
        }
    }
}

@Composable
fun Thumb(v: VideoItem, vm: AppVM, modifier: Modifier) {
    AsyncImage(
        model = vm.thumb(v.thumb), contentDescription = null, contentScale = ContentScale.Crop,
        modifier = modifier.background(MaterialTheme.colorScheme.surfaceContainerHigh)
    )
}

@Composable
fun DurationBadge(sec: Long, modifier: Modifier = Modifier) {
    if (sec > 0) Text(
        fmt(sec), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium,
        modifier = modifier.background(Color(0xCC000000), RoundedCornerShape(8.dp)).padding(horizontal = 7.dp, vertical = 2.dp)
    )
}

@Composable
fun Avatar(v: VideoItem, size: Dp) {
    Box(Modifier.size(size).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceContainerHigh), Alignment.Center) {
        if (v.avatar.isNotBlank()) AsyncImage(
            model = v.avatar, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
        ) else Text(v.channel.take(1), fontWeight = FontWeight.Bold)
    }
}

@Composable
fun VideoMenu(v: VideoItem, vm: AppVM) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { open = true }) {
            Icon(Icons.Default.MoreVert, "المزيد", tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(
                text = { Text(if (vm.isFav(v.id)) "إزالة من المفضلة" else "إضافة للمفضلة") },
                onClick = { open = false; vm.toggleFav(v) }
            )
            DropdownMenuItem(text = { Text("مشاركة") }, onClick = { open = false; share(ctx, v.id) })
        }
    }
}

@Composable
fun VideoHero(v: VideoItem, vm: AppVM) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).clickable { vm.open(v.id) }) {
        Box(Modifier.clip(RoundedCornerShape(20.dp))) {
            Thumb(v, vm, Modifier.fillMaxWidth().aspectRatio(16 / 9f))
            DurationBadge(v.duration, Modifier.align(Alignment.BottomEnd).padding(10.dp))
        }
        Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.Top) {
            Avatar(v, 44.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(v.title, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    metaText(v, true), maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            VideoMenu(v, vm)
        }
    }
}

@Composable
fun VideoRow(v: VideoItem, vm: AppVM, onClick: () -> Unit = { vm.open(v.id) }) {
    val c = MaterialTheme.colorScheme.onSurfaceVariant
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 8.dp)) {
        Box(Modifier.width(160.dp).aspectRatio(16 / 9f).clip(RoundedCornerShape(12.dp))) {
            Thumb(v, vm, Modifier.fillMaxSize())
            DurationBadge(v.duration, Modifier.align(Alignment.BottomEnd).padding(6.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(v.title, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(v.channel, color = c, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                if (v.verified) {
                    Spacer(Modifier.width(4.dp))
                    Icon(Icons.Default.CheckCircle, null, tint = c, modifier = Modifier.size(13.dp))
                }
            }
            Text(metaText(v, false), color = c, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        VideoMenu(v, vm)
    }
}

@Composable
fun SectionTitle(t: String) {
    Column(Modifier.padding(start = 16.dp, end = 16.dp, top = 22.dp, bottom = 6.dp)) {
        Text(t, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Box(Modifier.width(26.dp).height(3.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary))
    }
}

@Composable
fun Skeleton() {
    val a by rememberInfiniteTransition(label = "sk").animateFloat(
        initialValue = 0.4f, targetValue = 1f, animationSpec = infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "a"
    )
    val c = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.10f * a)
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Box(Modifier.fillMaxWidth().aspectRatio(16 / 9f).clip(RoundedCornerShape(20.dp)).background(c))
        Spacer(Modifier.height(12.dp))
        Box(Modifier.fillMaxWidth(0.8f).height(14.dp).clip(CircleShape).background(c))
        Spacer(Modifier.height(24.dp))
        repeat(3) {
            Row(Modifier.padding(bottom = 16.dp)) {
                Box(Modifier.width(160.dp).aspectRatio(16 / 9f).clip(RoundedCornerShape(12.dp)).background(c))
                Spacer(Modifier.width(12.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.width(140.dp).height(12.dp).clip(CircleShape).background(c))
                    Box(Modifier.width(90.dp).height(10.dp).clip(CircleShape).background(c))
                }
            }
        }
    }
}

@Composable
fun ErrorBox(msg: String, retry: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("تعذّر التحميل", style = MaterialTheme.typography.titleMedium)
        Text(msg, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        Button(onClick = retry) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(6.dp)); Text("إعادة المحاولة") }
    }
}

@Composable
fun EmptyBox(t: String) = Box(Modifier.fillMaxSize(), Alignment.Center) {
    Text(t, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

// ───────── الشاشة الرئيسية ─────────

@Composable
fun BrandLogo() {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(
                Modifier.size(width = 44.dp, height = 31.dp).background(MaterialTheme.colorScheme.primary, RoundedCornerShape(9.dp)),
                Alignment.Center
            ) { Icon(Icons.Default.PlayArrow, null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(26.dp)) }
            val red = MaterialTheme.colorScheme.primary
            Text(
                buildAnnotatedString {
                    append(BRAND_A)
                    withStyle(SpanStyle(color = red)) { append(" $BRAND_B") }
                },
                fontSize = 24.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp
            )
        }
    }
}

@Composable
fun HomeScreen(vm: AppVM, goSearch: () -> Unit, goSettings: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            BrandLogo()
            Spacer(Modifier.weight(1f))
            IconButton(onClick = goSearch) { Icon(Icons.Default.Search, "بحث") }
            Spacer(Modifier.width(4.dp))
            Box(
                Modifier.size(36.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceContainerHigh).clickable(onClick = goSettings),
                Alignment.Center
            ) { Icon(Icons.Default.Person, "الإعدادات", Modifier.size(22.dp)) }
        }
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            item { PillBox(onClick = goSearch) { Icon(ExploreIcon, "استكشاف", Modifier.size(22.dp)) } }
            itemsIndexed(vm.cats) { i, c -> Pill(c.first, vm.cat == i) { vm.setCat(i) } }
        }
        when (val s = vm.home) {
            Load.Busy -> Skeleton()
            is Load.Err -> ErrorBox(s.msg) { vm.loadHome() }
            is Load.Ok -> if (s.v.isEmpty()) EmptyBox("لا توجد نتائج") else LazyColumn(
                Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 14.dp)
            ) {
                item { VideoHero(s.v.first(), vm) }
                item { SectionTitle("مقترح لك") }
                items(s.v.drop(1), key = { it.id }) { VideoRow(it, vm) }
            }
        }
    }
}

@Composable
fun SearchScreen(vm: AppVM) {
    val kb = LocalSoftwareKeyboardController.current
    val cs = MaterialTheme.colorScheme
    val sortNames = listOf("الأكثر صلة", "الأحدث", "الأكثر مشاهدة")
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = vm.query, onValueChange = vm::onQuery, singleLine = true, shape = CircleShape,
            placeholder = { Text("ابحث في $BRAND_A $BRAND_B") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            trailingIcon = { if (vm.query.isNotEmpty()) IconButton(onClick = { vm.onQuery("") }) { Icon(Icons.Default.Close, null) } },
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = cs.surfaceContainerHigh, unfocusedContainerColor = cs.surfaceContainerHigh,
                focusedBorderColor = cs.primary, unfocusedBorderColor = Color.Transparent
            ),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { kb?.hide(); vm.search() }),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        )
        if (vm.suggestions.isNotEmpty()) {
            vm.suggestions.forEach { s ->
                Row(
                    Modifier.fillMaxWidth().clickable { kb?.hide(); vm.search(s) }.padding(horizontal = 20.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Search, null, Modifier.size(18.dp), tint = cs.onSurfaceVariant)
                    Spacer(Modifier.width(12.dp))
                    Text(s)
                }
            }
        } else {
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Pill("فيديو", vm.filter == "videos") { vm.setFilter("videos") }
                Pill("موسيقى", vm.filter == "music_songs") { vm.setFilter("music_songs") }
                Spacer(Modifier.weight(1f))
                Picker(sortNames[vm.sort], listOf(0, 1, 2), { sortNames[it] }) { vm.sort = it }
            }
            Spacer(Modifier.height(8.dp))
            when (val r = vm.results) {
                null -> EmptyBox("اكتب ما تريد البحث عنه")
                Load.Busy -> Skeleton()
                is Load.Err -> ErrorBox(r.msg) { vm.search() }
                is Load.Ok -> {
                    val list = vm.sorted(r.v)
                    LazyColumn(Modifier.fillMaxSize()) {
                        items(list, key = { it.id }) { VideoRow(it, vm) }
                        item {
                            LaunchedEffect(list.size) { vm.loadMore() }
                            if (vm.loadingMore) Box(Modifier.fillMaxWidth().padding(16.dp), Alignment.Center) { CircularProgressIndicator() }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ListScreen(title: String, list: List<VideoItem>, empty: String, vm: AppVM, onClear: (() -> Unit)? = null) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 12.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            if (onClear != null && list.isNotEmpty()) TextButton(onClick = onClear) {
                Icon(Icons.Default.Delete, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("مسح")
            }
        }
        if (list.isEmpty()) EmptyBox(empty)
        else LazyColumn(Modifier.fillMaxSize()) { items(list, key = { it.id }) { VideoRow(it, vm) } }
    }
}

@Composable
fun SwitchRow(title: String, sub: String, on: Boolean, change: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = on, onCheckedChange = change)
    }
}

@Composable
fun SettingsScreen(vm: AppVM, onBack: () -> Unit) {
    var inst by remember { mutableStateOf(vm.instance) }
    var reg by remember { mutableStateOf(vm.region) }
    val round = RoundedCornerShape(16.dp)
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع") }
            Text("الإعدادات", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        OutlinedTextField(inst, { inst = it }, label = { Text("خادم Piped API") }, singleLine = true, shape = round, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(
            reg, { reg = it.take(2).uppercase() }, label = { Text("رمز دولة الترند (IQ, SA, EG, US…)") },
            singleLine = true, shape = round, modifier = Modifier.fillMaxWidth()
        )
        Button(onClick = { vm.saveServer(inst, reg) }) { Text("حفظ وإعادة التحميل") }
        HorizontalDivider()
        SwitchRow("توفير البيانات", "صور مصغّرة منخفضة الجودة وفيديو 360p افتراضياً", vm.saver) { vm.setSaver(it) }
        SwitchRow("صوت فقط افتراضياً", "يوفّر بيانات وبطارية", vm.audioDefault) { vm.setAudioDefault(it) }
        if (Build.VERSION.SDK_INT >= 31) SwitchRow("ألوان Material You", "ألوان تتكيّف مع خلفية الجهاز بدل الأحمر", vm.dynamic) { vm.setDynamic(it) }
        Text("المظهر")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("تلقائي", "فاتح", "داكن").forEachIndexed { i, s -> Pill(s, vm.theme == i) { vm.setTheme(i) } }
        }
        Text("اتجاه الواجهة")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("تلقائي", "LTR", "RTL").forEachIndexed { i, s -> Pill(s, vm.dir == i) { vm.setDir(i) } }
        }
        Spacer(Modifier.height(16.dp))
    }
}

// ───────── الهيكل العام والتنقل ─────────

@Composable
fun LinkDialog(onDismiss: () -> Unit, onOpen: (String) -> Unit) {
    var t by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("فتح رابط فيديو") },
        text = { OutlinedTextField(t, { t = it }, singleLine = true, placeholder = { Text("الصق الرابط أو معرّف الفيديو") }) },
        confirmButton = { TextButton(onClick = { extractId(t)?.let(onOpen) }) { Text("تشغيل") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
fun BottomBar(tab: Int, onTab: (Int) -> Unit, onLink: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val colors = NavigationBarItemDefaults.colors(
        selectedIconColor = cs.primary, selectedTextColor = cs.primary, indicatorColor = Color.Transparent,
        unselectedIconColor = cs.onSurfaceVariant, unselectedTextColor = cs.onSurfaceVariant
    )
    NavigationBar(containerColor = cs.surfaceContainer) {
        NavigationBarItem(
            tab == 0, { onTab(0) }, { Icon(if (tab == 0) Icons.Default.Home else Icons.Outlined.HomeOutlined, null) },
            label = { Text("الرئيسية") }, colors = colors
        )
        NavigationBarItem(tab == 1, { onTab(1) }, { Icon(Icons.Default.Search, null) }, label = { Text("بحث") }, colors = colors)
        NavigationBarItem(
            false, onLink,
            { Box(Modifier.size(40.dp).border(1.5.dp, cs.onSurfaceVariant, CircleShape), Alignment.Center) { Icon(Icons.Default.Add, "فتح رابط", Modifier.size(24.dp)) } },
            colors = colors
        )
        NavigationBarItem(
            tab == 3, { onTab(3) }, { Icon(if (tab == 3) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null) },
            label = { Text("المفضلة") }, colors = colors
        )
        NavigationBarItem(tab == 4, { onTab(4) }, { Icon(HistoryIcon, null) }, label = { Text("السجل") }, colors = colors)
    }
}

@Composable
fun App(vm: AppVM, pip: Boolean) {
    var tab by rememberSaveable { mutableIntStateOf(0) } // 0 رئيسية، 1 بحث، 3 مفضلة، 4 سجل، 5 إعدادات
    var link by remember { mutableStateOf(false) }
    if (vm.playingId != null) {
        BackHandler(enabled = !pip) { vm.close() }
        PlayerScreen(vm, pip)
    } else {
        BackHandler(enabled = tab != 0) { tab = 0 }
        if (link) LinkDialog({ link = false }) { link = false; vm.open(it) }
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = { BottomBar(tab, { tab = it }, { link = true }) }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0 -> HomeScreen(vm, { tab = 1 }, { tab = 5 })
                    1 -> SearchScreen(vm)
                    3 -> ListScreen("المفضلة", vm.favs, "لم تضف أي فيديو للمفضلة بعد", vm)
                    4 -> ListScreen("السجل", vm.hist, "سجل المشاهدة فارغ", vm, onClear = vm::clearHistory)
                    else -> SettingsScreen(vm) { tab = 0 }
                }
            }
        }
    }
}

// ───────── المشغّل ─────────

@Composable
fun PlayerScreen(vm: AppVM, pip: Boolean) {
    val ctx = LocalContext.current
    val exo = remember { PlayerHolder.get(ctx) }
    val full = pip || LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    DisposableEffect(exo) {
        val l = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                // نُظهر سبب الخطأ الفعلي (مثل Response code: 403) ليسهل تشخيص أي مشكلة
                val why = generateSequence(error.cause) { it.cause }.mapNotNull { it.message }.firstOrNull()?.take(120)
                vm.playError = error.errorCodeName + (why?.let { " — $it" } ?: "")
            }
            override fun onPlaybackStateChanged(state: Int) { if (state == Player.STATE_READY) vm.playError = null }
        }
        exo.addListener(l)
        onDispose { exo.removeListener(l) }
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).then(if (full) Modifier else Modifier.statusBarsPadding())) {
        Box(if (full) Modifier.fillMaxSize() else Modifier.fillMaxWidth().aspectRatio(16 / 9f)) {
            AndroidView(
                factory = { c ->
                    PlayerView(c).apply {
                        player = exo
                        setShowSubtitleButton(true)
                        setShowNextButton(false)
                        setShowPreviousButton(false)
                    }
                },
                update = { it.useController = !pip },
                onRelease = { it.player = null },
                modifier = Modifier.fillMaxSize().background(Color.Black)
            )
            if (vm.audioOnly) {
                AsyncImage(
                    model = (vm.detail as? Load.Ok)?.v?.thumb, contentDescription = null, contentScale = ContentScale.Crop,
                    alpha = 0.45f, modifier = Modifier.fillMaxSize()
                )
                Text("وضع الصوت فقط", color = Color.White, modifier = Modifier.align(Alignment.Center))
            }
            if (!pip) IconButton(onClick = vm::close, modifier = Modifier.align(Alignment.TopStart)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
            }
        }
        if (full) return@Column

        when (val d = vm.detail) {
            Load.Busy -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
            is Load.Err -> ErrorBox(d.msg) { vm.playingId?.let { id -> vm.open(id, fresh = true) } }
            is Load.Ok -> {
                val x = d.v
                val opts = remember(x) { qualityOptions(x) }
                val item = VideoItem(x.id, x.title, x.channel, x.thumb, x.duration)
                val fav = vm.isFav(x.id)
                LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                    vm.playError?.let { e ->
                        item {
                            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("تعذّر التشغيل ($e)", color = MaterialTheme.colorScheme.error, modifier = Modifier.weight(1f))
                                TextButton(onClick = { vm.open(x.id, fresh = true) }) { Text("إعادة") }
                            }
                        }
                    }
                    item {
                        Column(Modifier.padding(16.dp)) {
                            Text(x.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            val meta = listOfNotNull(
                                x.channel.ifBlank { null },
                                if (x.views > 0) "${compact(x.views)} مشاهدة" else null,
                                if (x.likes >= 0) "${compact(x.likes)} إعجاب" else null
                            ).joinToString(" • ")
                            Text(meta, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row(
                                Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 10.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(onClick = { vm.toggleFav(item) }) {
                                    Icon(
                                        if (fav) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null,
                                        tint = if (fav) MaterialTheme.colorScheme.primary else LocalContentColor.current
                                    )
                                }
                                IconButton(onClick = { share(ctx, x.id) }) { Icon(Icons.Default.Share, null) }
                                Pill("صوت فقط", vm.audioOnly) { vm.toggleAudio() }
                                if (opts.isNotEmpty()) Picker("الجودة: ${vm.quality?.height ?: "-"}p", opts, { "${it.height}p" }) { vm.setQuality(it) }
                                Picker(
                                    "السرعة: ${if (vm.speed % 1f == 0f) vm.speed.toInt().toString() else vm.speed.toString()}x",
                                    listOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f, 3f),
                                    { if (it % 1f == 0f) "${it.toInt()}x" else "${it}x" }
                                ) { vm.setSpeed(it) }
                                Picker(
                                    "النوم: ${if (vm.sleepMin == 0) "إيقاف" else "${vm.sleepMin} د"}",
                                    listOf(0, 15, 30, 60), { if (it == 0) "إيقاف" else "$it دقيقة" }
                                ) { vm.sleep(it) }
                            }
                            var open by remember(x.id) { mutableStateOf(false) }
                            if (x.description.isNotBlank()) Text(
                                x.description, maxLines = if (open) Int.MAX_VALUE else 3, overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.bodyMedium, modifier = Modifier.clickable { open = !open }
                            )
                        }
                    }
                    items(x.related, key = { it.id }) { VideoRow(it, vm) }
                }
            }
        }
    }
}
