# قواعد إضافية عند الحاجة (Compose وMedia3 وCoil تضيف قواعدها تلقائياً)

# ── NewPipeExtractor (منقولة من قواعد تطبيق NewPipe) ──
-keep class org.schabi.newpipe.extractor.timeago.patterns.** { *; }
-keep class org.mozilla.javascript.* { *; }
-keep class org.mozilla.javascript.** { *; }
-keep class org.mozilla.javascript.engine.** { *; }
-keep class org.mozilla.classfile.ClassFileWriter
-dontwarn org.mozilla.javascript.JavaToJSONConverters
-dontwarn org.mozilla.javascript.tools.**
-keep class javax.script.** { *; }
-dontwarn javax.script.**
-keep class jdk.dynalink.** { *; }
-dontwarn jdk.dynalink.**

# OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**

# Protobuf (lite) المستخدم داخل المستخرج
-keepclassmembers class * extends com.google.protobuf.GeneratedMessageLite {
    <fields>;
}
-dontwarn javax.annotation.**
